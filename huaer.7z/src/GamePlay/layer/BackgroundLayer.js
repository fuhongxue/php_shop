/**
 * Created by wangzhigang on 15/8/21.
 */

var BG_ZORDER = {
    BACKGROUND : 1,         //大背景图
    UI         : 2,         //上下两个背景图
    ROAD       : 3,         //道路
    GROUND1    : 4,         //GROUND1背景图
    GROUND2    : 5,    
    GROUND3    : 6,
    SKY        : 7,
    TREE2      : 8,
    TREE3      : 9,
    TREE4      : 10,
    REED       : 11
}


var GPBackgroundLayer = cc.Layer.extend({
    bottomBg : null,            //底部技能背景框
    roadBg   : null,            //一个道路背景图对象
    tree2    : null,   //Tree2背景移动节点
    tree3    : null,   //Tree2背景移动节点
    tree4    : null,   //Tree2背景移动节点
    sky1      : null,
    sky2      : null,
    sky3      : null,
    ground1   : null,
    ground2   : null,
    ground3   : null,

    tree2Vector : [],
    ctor:function () {
        this._super();

        this.sky3 = new cc.Node();
        this.sky2 = new cc.Node();
        this.sky1 = new cc.Node();


        this.loadBg();
        this.loadTopBg();
        this.loadBottomBg();
        this.loadRoad();
        this.loadGround1();
        this.loadGround2();
        this.loadGround3();
        this.loadSky3();
        this.loadSky2();
        this.loadSky1();


        this.loadTree2();
        this.loadTree3();
        this.loadTree4();
        this.loadParallaxNode();
        return true;
    },
    loadBg : function(){
        var node = new cc.Sprite(res.map_mpd_bg1);
        this.addChild(node);

        node.setPosition(GC.w2, GC.h2);
        node.setScale(GC.SCALE_RATE);
    },

    loadTopBg : function() {
        var node = new cc.Sprite(res.ui_top);
        this.addChild(node,200);
        node.setScale(GC.SCALE_RATE);
        node.setPosition(GC.w2, GC.h - node.getBoundingBox().height/2);

    },
    loadBottomBg : function() {
        var node = new cc.Sprite(res.ui_top2);
        this.addChild(node);
        node.setScale(GC.SCALE_RATE);
        node.setPosition(GC.w2,node.getBoundingBox().height/2);

        this.bottomBg = node;
    },
    loadRoad : function() {
        var road = new cc.Node();

        this.addChild(road,100);

        for (var i = 0; i < 4; i++) {

            var node = new cc.Sprite(res.map_mpd_road1);
            node.setScale(GC.SCALE_RATE);

            var posY = node.getBoundingBox().height/2 + this.bottomBg.getBoundingBox().height;
            var posX = node.getBoundingBox().width/2+node.getBoundingBox().width*(i);            

            node.setPosition(posX,posY);

            if(i == 3){
                this.roadBg = node;
            }

            road.addChild(node);
        };
    },
    loadGround1 : function() {
        var ground = new cc.Node();

        this.ground1 = ground;

        for (var i = 0; i < 4; i++) {
            var node = new cc.Sprite(res.map_mpd_ground1);
            node.setScale(GC.SCALE_RATE);
            node.setAnchorPoint(0,0.5);

            var posY = node.getBoundingBox().height/2 + this.bottomBg.getBoundingBox().height + this.roadBg.getBoundingBox().height;
            var posX = node.getBoundingBox().width*(i);
            posY  = posY - 20;
            node.setPosition(posX, posY);
            node.totalNum = 4;

            GameManager.getInstance().getGround().push(node);

            ground.addChild(node);
        };

    },
    loadGround2 : function() {
        var ground = new cc.Node();
        // this.addChild(ground,99);

        this.ground2 = ground;

        for (var i = 0; i < 4; i++) {
            var node = new cc.Sprite(res.map_mpd_ground2);
            node.setScale(GC.SCALE_RATE);
            node.setAnchorPoint(0,0.5);

            var posY = node.getBoundingBox().height/2 + this.bottomBg.getBoundingBox().height + this.roadBg.getBoundingBox().height;
            var posX = node.getBoundingBox().width*(i);
            posY  = posY - 20+50;
            node.setPosition(posX, posY);
            node.totalNum = 4;


            ground.addChild(node);

            GameManager.getInstance().getGround().push(node);

        };

    },
    loadGround3 : function() {
        var ground = new cc.Node();
        // this.addChild(ground,99);

        this.ground3 = ground;

        for (var i = 0; i < 6; i++) {
            var node = new cc.Sprite(res.map_mpd_ground3);
            node.setScale(GC.SCALE_RATE);
            node.setAnchorPoint(0,0.5);
            var posY = node.getBoundingBox().height/2 + this.bottomBg.getBoundingBox().height + this.roadBg.getBoundingBox().height;
            var posX = node.getBoundingBox().width*(i);
            posY  = posY - 20+100;
            node.setPosition(posX, posY);
            
            node.totalNum = 6;


            ground.addChild(node);

            GameManager.getInstance().getGround().push(node);
        };

    },
    loadSky1 : function() {
        var sky = new cc.Node();
        this.sky1.addChild(sky);


        for (var i = 0; i < 4; i++) {
            var node = new cc.Sprite(res.map_mpd_sky1);
            node.setScale(GC.SCALE_RATE);
            node.setAnchorPoint(0,0.5);
            var posY = node.getBoundingBox().height/2 + this.bottomBg.getBoundingBox().height + this.roadBg.getBoundingBox().height;
            var posX = node.getBoundingBox().width*(i);
            posY  = posY +25 + 250;
            node.setPosition(posX, posY);

            node.totalNum = 4;

            sky.addChild(node);

            GameManager.getInstance().getSky().push(node);
        };
    },
    loadSky2 : function() {
        var sky = new cc.Node();
        this.sky2.addChild(sky);

        for (var i = 0; i < 5; i++) {
            var node = new cc.Sprite(res.map_mpd_sky2);
            node.setScale(GC.SCALE_RATE);
            node.setAnchorPoint(0,0.5);
            var posY = node.getBoundingBox().height/2 + this.bottomBg.getBoundingBox().height + this.roadBg.getBoundingBox().height;
            var posX = node.getBoundingBox().width*(i);
            posY  = posY +25 + 200;
            node.setPosition(posX, posY);


            node.totalNum = 5;

            GameManager.getInstance().getSky().push(node);
            sky.addChild(node);
        };
    },
    loadSky3 : function() {
        var sky = new cc.Node();
        this.sky3.addChild(sky);

        for (var i = 0; i < 6; i++) {
            var node = new cc.Sprite(res.map_mpd_sky3);
            node.setAnchorPoint(0,0.5);
            node.setScale(GC.SCALE_RATE);
            var posY = node.getBoundingBox().height/2 + this.bottomBg.getBoundingBox().height + this.roadBg.getBoundingBox().height;
            var posX = node.getBoundingBox().width*(i);
            posY  = posY +25 + 150;
            node.setPosition(posX, posY);


            node.totalNum = 6;

            GameManager.getInstance().getSky().push(node);
            sky.addChild(node);
        };
    },
    loadTree2 : function() {
        var tree = new cc.Node();
        this.tree2 = tree;

        var nodeArr = [
            [
               300, //posXOffset
               50,  //posYOffset
            ],

            [
                600,
                50,
            ],
            [
                700,
                50,
            ],
        ];

        for (var i = 0; i < nodeArr.length; i++) {

            var arr = new Array();
            arr = nodeArr[i];


            var posXOffset = arr[0];
            var posYOffset = arr[1];


            var node = new cc.Sprite(res.map_mpd_Tree2);
            node.setScale(GC.SCALE_RATE);
            var posY = node.getBoundingBox().height/2 + this.bottomBg.getBoundingBox().height + this.roadBg.getBoundingBox().height;
            var posX = node.getBoundingBox().width/2;
            posY  = posY + 40;
            posX  = posX + posXOffset;

            node.setPosition(posX, posY);

            tree.addChild(node);    
   
            this.tree2Vector.push(node);

        };

    },
    loadTree3 : function() {
        var tree = new cc.Node();
        // this.addChild(tree,300);

        this.tree3 = tree;


        var nodeArr = [
            [
               0, //posXOffset
               0,  //posYOffset
            ],

            [
                100,
                50,
            ],
            [
                500,
                50,
            ],
            [
                800,
                50,
            ],
        ];

        for (var i = 0; i < nodeArr.length; i++) {
            var arr = new Array();
            arr = nodeArr[i];

            var posXOffset = arr[0];
            var posYOffset = arr[1];

            var node = new cc.Sprite(res.map_mpd_Tree3);
            node.setScale(GC.SCALE_RATE);

            var posY = node.getBoundingBox().height/2 + this.bottomBg.getBoundingBox().height + this.roadBg.getBoundingBox().height;
            var posX = node.getBoundingBox().width/2;
            posY  = posY + 100;
            posX  = posX + posXOffset;


            node.setPosition(posX, posY);
            tree.addChild(node);

            this.tree2Vector.push(node);

        };

    },
    loadTree4 : function() {
        var tree = new cc.Node();
        // this.addChild(tree,300);

        this.tree4 = tree;

        var nodeArr = [
            [
                50, //posXOffset
                0, //posYOffset
            ],

            [
                250,            
                100,
            ],
            [
                430,           
                500,

            ],
            [
                680,

                800,
            ],
            [
                900,
                800,
            ],
        ];

        for (var i = 0; i < nodeArr.length; i++) {
            var arr = new Array();
            arr = nodeArr[i];

            var posXOffset = arr[0];
            var posYOffset = arr[1];

            var node = new cc.Sprite(res.map_mpd_Tree4);
            node.setScale(GC.SCALE_RATE);
            var posY = node.getBoundingBox().height/2 + this.bottomBg.getBoundingBox().height + this.roadBg.getBoundingBox().height;
            var posX = node.getBoundingBox().width/2;
            posY  = posY+150;
            posX  = posX + posXOffset;


            node.setPosition(posX, posY);
            tree.addChild(node);


            this.tree2Vector.push(node);

        };

    },
    loadParallaxNode : function() {
        var node = new cc.ParallaxNode();
        node.addChild(this.tree2, -1, cc.p(0.4, 0), cc.p(0,0));
        node.addChild(this.tree3, -1, cc.p(0.6, 0), cc.p(0,0));
        node.addChild(this.tree4, -1, cc.p(0.8, 0), cc.p(0,0));

        node.addChild(this.sky1, 2, cc.p(0.8, 0), cc.p(0,0));
        node.addChild(this.sky2, 1, cc.p(0.6, 0), cc.p(0,0));
        node.addChild(this.sky3, 0, cc.p(0.4, 0), cc.p(0,0));

        node.addChild(this.ground1, -2, cc.p(0.8, 0), cc.p(0,0));
        node.addChild(this.ground2, -3, cc.p(0.6, 0), cc.p(0,0));
        node.addChild(this.ground3, -4, cc.p(0.4, 0), cc.p(0,0));


        this.addChild(node,99);

        GameManager.getInstance().setParallaxLayer(node);

        GameManager.getInstance().setTree2Vector(node);

        GameManager.getInstance().setTree2Vector(this.tree2Vector);
        GameManager.getInstance().setTree2(this.tree2);

    }
});