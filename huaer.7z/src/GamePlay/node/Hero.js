
/**
 * Created by wangzhigang on 15/4/20.
 */

var Hero = cc.Sprite.extend({ 
	speed		: 0,
	direction	: GC.CHARACTER_DIRECTION.RIGHT,
	isMove      : false,
	level       : 0,

	weapon 		: null,
	hpBar       : null,

	hpMax       : 0,
	hp          : 0,
	attack      : 0,    //攻击
	def         : 0,    //防御
	needGold　　: 0,    //升级所需金钱
	ctor : function() {
		this._super(res.wukong_standby_r_1);

		this.loadConfig();
		this.loadAnimation();
		this.loadWeapon();
		this.loadHpBar();
		this.schedule(this.addHp, 1);
		return true;
	},
	loadConfig : function() {
		this.speed = GC.HERO_SPEED;
		this.level = 0;

		var data =  GameManager.getInstance().getCharacterData();

		this.attack = 5//data.attack;
		this.hp     = 2//data.hp;
		this.hpMax  = 2//data.hpMax;
		this.needGold = data.needGold;

		this.setScale(GC.SCALE_RATE);

	},
	loadAnimation : function() {
		this.stopActionByTag(998);

		var dir = this.direction == GC.CHARACTER_DIRECTION.RIGHT ? "r" : "l";

		if(this.getIsMove())
		{
		    var prefix =  "wukong_run_" + dir +  "_";
		    this.setTexture(res[prefix + "1"]);

		    var animation = cc.Animation.create();  //利用动画保存每一帧的图片

		    for (var i = 1; i <= 4; i++) {
		    	animation.addSpriteFrameWithFile(res[prefix + i ]);
		    };

		    animation.setDelayPerUnit(0.1);  //每一帧播放的间隔
		    // animation.setRestoreOriginalFrame(true);  //是否回到第一帧播放
		    var animate = cc.animate(animation).repeatForever();
		    animate.tag = 998;
		    this.runAction(animate);

		}else {
			var prefix =  "wukong_standby_" + dir +  "_";
			this.setTexture(res[prefix + "1"]);

			var animation = cc.Animation.create();  //利用动画保存每一帧的图片

			for (var i = 1; i <= 4; i++) {
				animation.addSpriteFrameWithFile(res[prefix + i ]);
			};

			animation.setDelayPerUnit(0.1);  //每一帧播放的间隔
			var animate = cc.animate(animation).repeatForever();
			animate.tag = 998;
			this.runAction(animate);
		}

		this.loadWeapon();
	},

	loadWeapon : function() {
		if(!this.weapon){
			var node = new cc.Sprite(res["wa_0" +　(this.level+1) ]);
			this.addChild(node);
			node.setAnchorPoint(0,0);

			var moveUp = cc.moveBy(0.1,cc.p(0,1));
			var moveFront = cc.moveBy(0.1,cc.p(1,0));
			var moveDown = cc.moveBy(0.1,cc.p(0,-1));
			var moveBehind = cc.moveBy(0.1,cc.p(-1,0));

			var action = cc.sequence(cc.spawn(moveUp,moveFront),cc.spawn(moveDown,moveBehind) );
			node.runAction(action.repeatForever());

			node.setPosition(this.getContentSize().width-8,this.getContentSize().height-36);

			this.weapon = node;
		}

		if(this.getIsMove()){
			this.weapon.setVisible(true);
			if(this.direction == GC.CHARACTER_DIRECTION.RIGHT){
				this.weapon.setPosition(this.getContentSize().width-8,this.getContentSize().height-36);
			}else{
				this.weapon.setPosition(-this.getContentSize().width+13,this.getContentSize().height-36);
			}
		}else{
			this.weapon.setVisible(false);
			// this.weapon.setPosition(0,this.getContentSize().height-36);
			// this.weapon.setZOrder(-1)

		}


	},
	addHp : function(){
		if (this.hp < this.hpMax) {
			this.hp = this.hp + 1;
			this.setHpBar();

		};
	},
	loadHpBar :function() {
		var node = new cc.Sprite(res.ui_hp_bg);
		this.addChild(node);
		node.setAnchorPoint(0,0);

		node.setPosition(-5,GC.HP_BAR_HIGHT)


		var node = new cc.Sprite(res.ui_hp_we);
		this.addChild(node);
		node.setAnchorPoint(0,0);

		node.setPosition(-5,GC.HP_BAR_HIGHT);

		this.hpBar = node;
	},
	setHpBar : function() {
		var percent = this.hp/this.hpMax;
		if(percent > 0){
			this.hpBar.setScaleX(percent);
		}else{
			this.hpBar.setScaleX(0);
		}
	},
	getSpeed : function() {
		return this.speed;
	},
	setSpeed : function(percent) {
		this.speed = GC.HERO_SPEED* percent;
	},
	setDirection : function(dir) {
		if(this.direction != dir){
			this.direction = dir;
			this.loadAnimation();
 			var cVector = GameManager.getInstance().getCharacterVector();

 			for (var i = 0; i < cVector.length; i++) {
 				var node = cVector[i];
 				if(i == 0){
 					// node.setPositionX( node.getPositionX() +  heroObj.getSpeed() * dt*dir);
 				}else{
 					node.isDone = false;
 				}
 			};	
			
		}
	},
	getDirection : function() {
		return this.direction;
	},
	getIsMove : function() {
		return this.isMove;
	},
	setIsMove : function(i) {
		this.isMove = i;
		this.loadAnimation();
	},
	onHit : function(att,m_isDeath) {
		this.hp = this.hp - att;

		// if(this.hp > 0){
		// 	cc.log("hero die");
		// }else{
			this.setHpBar();

			if(!m_isDeath){
				var dir = this.getDirection() == GC.CHARACTER_DIRECTION.RIGHT ? 1 : -1;
				var action = cc.moveBy(0.01,cc.p(-80*dir,0));
				this.runAction(action);
			}
		// }
	},
	getAttack : function(){
		return this.attack;
	},
	getCollisionRect : function() {

		var heroPos = this.getPosition();
		var heroRect;

		if(this.direction == GC.CHARACTER_DIRECTION.RIGHT ){
			heroRect = cc.rect(
			    heroPos.x,
			    heroPos.y ,
			    this.getBoundingBox().width + this.weapon.getBoundingBox().width*GC.SCALE_RATE,
			    this.getBoundingBox().height);
		}else{
			heroRect = cc.rect(
			    heroPos.x-this.weapon.getBoundingBox().width*GC.SCALE_RATE,
			    heroPos.y ,
			    this.getBoundingBox().width + this.weapon.getBoundingBox().width*GC.SCALE_RATE,
			    this.getBoundingBox().height)
		}

		return heroRect;
	},
	getWeapon : function() {
		return this.weapon;
	},

});