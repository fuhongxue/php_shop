

var Partner = cc.Sprite.extend({ 
	pType : null,
	direction	: GC.CHARACTER_DIRECTION.RIGHT,

	ctor : function(type) {
		this.pType = type;

		this._super(res["p0" + type + "_run_r_01"]);
		this.loadConfig();
		this.loadAnimation();

	},
	loadConfig : function(){
		// this.setScale(GC.SCALE_RATE);
	},
	loadAnimation : function(){
		if (this.pType == 3) {
			cc.log("this.getBoundingBox().width: " + this.getBoundingBox().width);
		};

		this.stopActionByTag(998);

		var dir = this.direction == GC.CHARACTER_DIRECTION.RIGHT ? "r" : "l";

		var prefix =  "p0" + this.pType +"_run_" + dir+"_0";
		this.setTexture(res[prefix + "1"]);
		this.setAnchorPoint(0,0);
		var animation = cc.Animation.create();  //利用动画保存每一帧的图片

		for (var i = 1; i <= 4; i++) {
			animation.addSpriteFrameWithFile(res[prefix + i ]);
		};

		animation.setDelayPerUnit(0.1);  //每一帧播放的间隔
		// animation.setRestoreOriginalFrame(true);  //是否回到第一帧播放
		var animate = cc.animate(animation).repeatForever();
		animate.tag = 998;
		this.runAction(animate);
	},
	setDirection : function(dir) {
		if(this.direction != dir){
			this.direction = dir;
			this.loadAnimation();
		}
	},
});