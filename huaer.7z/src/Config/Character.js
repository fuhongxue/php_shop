/**
 * Created by wangzhigang on 15/8/28.
 */


 var Character1 = {
 	name : "孙悟空",

 	field : ["attack","hp","needGold"],
 	//攻击	血量	所需金钱
 	config : [
 		[1, 20, 0],
 		[2, 20, 5],

 	]
 }

 var Character2 = {
 	name : "唐僧",

 	field : ["hp","needGold"],
 	// 血量	所需金钱
 	config : [
 		[1, 0],
 		[2, 5],

 	]
 }

 var Character3 = {
 	name : "猪八戒",
 	field : ["attack","needGold"],
 	//攻击	所需金钱
 	config : [
 		[10, 100],
 		[20, 100],

 	]
 }


 var Character4 = {
 	name : "沙僧",

 	field : ["hp","needGold"],
 	// 血量	所需金钱
 	config : [
 		[1, 0],
 		[2, 5],
 	]
 }
