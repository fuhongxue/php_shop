
/**
 * Created by wangzhigang on 15/9/11.
 */

 var EffectManager = (function(){
 	function _EffectManager(){
 		this.playCommonAttFontEffect = function(value){
 			var pNode = new cc.Node();

 			var strValue = value.toString();
 			for (var i = 0; i < strValue.length; i++) {
 				if (strValue[i] == '.') {
 					var node = new cc.Sprite(res["f01_dot"]);

 				}else{
 					var node = new cc.Sprite(res["f01_" + strValue[i]]);
 				};
 				node.setPositionX(10*i)

 				pNode.addChild(node);
 			};


 			GameManager.getInstance().GPMainLayer.addChild(pNode);

 			var action1 = cc.moveBy(0.5,cc.p(0,50));
 			var action2 = cc.fadeOut(0.5);
 			var action3 = cc.moveBy(1,cc.p(0,80));
 			var callBack = cc.callFunc(function(){
 				this.removeAllChildrenWithCleanup(true)
 				this. removeFromParent(true);
 			}.bind(pNode));

 			// pNode.setCascadeColorEnabled(true);
 			pNode.setCascadeOpacityEnabled(true);
 			pNode.setPosition(cc.p(GC.w2,GC.h2));
 			pNode.setScale(2);
 			pNode.runAction(cc.sequence(action1,cc.spawn(action2,action3) ,callBack));
 		};
 		this.playWeaponEffect = function(){
 			var heroObj = GameManager.getInstance().getHeroObj();
 			var weapon = heroObj.getWeapon();

 			var node = new cc.Sprite();

 			var prefix =  "Attaca0";
 			var animation = cc.Animation.create();  //利用动画保存每一帧的图片

 			for (var i = 1; i <= 5; i++) {
 				animation.addSpriteFrameWithFile(res[prefix + i ]);
 			};

 			animation.setDelayPerUnit(0.1);  //每一帧播放的间隔
 			var animate = cc.animate(animation);
 			// animate.tag = 998;
 			node.runAction(animate);
 			node.setScale(4)

 			animation.setLoops(1);

 			GameManager.getInstance().GPMainLayer.addChild(node);
 			var pos = heroObj.convertToWorldSpace(cc.p(weapon.getPositionX() + 50,weapon.getPositionY() ));

 			cc.log("ddd: " + pos.x + "y: " + pos.y)

 			node.setPosition(pos);

 		};
 	}

 	var instance;

 	var _static = {
 		name : "EffctManager",

 		getInstance: function(){
 			if (instance === undefined) {
 			    instance = new _EffectManager();
 			}
 			return instance;
 		}
 	};
 	return _static;
 })();